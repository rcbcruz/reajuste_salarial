package com.example.reajustesalarial;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    EditText edtSalario;
    RadioGroup radioGroup;
    RadioButton radio40, radio45, radio50;
    Button btnCalcular;
    TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtSalario = findViewById(R.id.edtSalario);
        radioGroup = findViewById(R.id.radioGroup);
        radio40 = findViewById(R.id.radio40);
        radio45 = findViewById(R.id.radio45);
        radio50 = findViewById(R.id.radio50);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtResultado = findViewById(R.id.txtResultado);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String salarioStr = edtSalario.getText().toString();

                if (salarioStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Por favor, insira o salário!", Toast.LENGTH_SHORT).show();
                    return;
                }

                double salario = Double.parseDouble(salarioStr);
                double percentual = 0;

                int selectedId = radioGroup.getCheckedRadioButtonId();
                if (selectedId == R.id.radio40) {
                    percentual = 0.40;
                } else if (selectedId == R.id.radio45) {
                    percentual = 0.45;
                } else if (selectedId == R.id.radio50) {
                    percentual = 0.50;
                } else {
                    Toast.makeText(MainActivity.this, "Selecione um percentual!", Toast.LENGTH_SHORT).show();
                    return;
                }

                double novoSalario = salario + (salario * percentual);
                txtResultado.setText(String.format("Novo salário: R$ %.2f", novoSalario));
            }
        });
    }
}
